
class DatabaseSettings(object):

    def __init__(self):
        print("Data base class ")

    def run(self):
        return "ok"